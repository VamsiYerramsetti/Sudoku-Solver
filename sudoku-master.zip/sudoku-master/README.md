# Sudoku

Sudoku assignment AI: Principles & Techniques